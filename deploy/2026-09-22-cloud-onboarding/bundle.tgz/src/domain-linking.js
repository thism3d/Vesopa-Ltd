/**
 * Domains on an account: adding one, proving it points here, and serving it.
 *
 * ## Who may add a domain
 *
 * Anyone with an account. Registering a name through us is a purchase and goes
 * through checkout; naming one you already own is not, and gating it behind a
 * sale would mean a customer moving a live site cannot even see the panel they
 * are being asked to trust.
 *
 * ## What that gets them, and when
 *
 * Nothing, until the nameservers agree. A domain somebody typed into a form is
 * a claim, not a fact — the person typing it may not own it, and a platform
 * that serves a site, issues a certificate and accepts mail for any name it is
 * given is a platform being used to impersonate other people's domains. The
 * delegation is the proof: if the public DNS says the name is delegated to our
 * nameservers, then whoever controls the domain has pointed it at us
 * deliberately, and that is the only evidence worth acting on.
 *
 * ## And if they never do
 *
 * An EXTERNAL domain that has not verified within the grace period is dropped
 * from the account. It was never ours, we are not serving it, and leaving it in
 * a list forever means the panel shows domains this company does not host.
 *
 * A domain REGISTERED OR TRANSFERRED through us is never dropped by any of
 * this. It was paid for and it belongs to the customer whether it points at us
 * or at somebody else — that is what owning a domain means.
 */

const db = require('./db');
const hestia = require('./integrations/hestia');
const registrar = require('./integrations/domainnameapi');
const reality = require('./domain-reality');
const nameservers = require('./nameservers');
const { sendMail, shell, detailTable, escapeHtml } = require('./mailer');
const {
  SITE_URL, NAMESERVERS, DOMAIN_NS_GRACE_DAYS, POINT_HOSTNAME, MAIL_HOSTNAME,
} = require('./config');

/** The deadline written onto a new external domain, as a DATETIME string. */
/**
 * Progress, for whoever is watching.
 *
 * Every slow function here takes an `onStep(key, status, detail)` and calls it
 * as each piece of work starts and ends. The default does nothing, so a sweep
 * or a "check now" that has no page to report to costs nothing; a job started
 * from the add-domain form (src/domain-setup.js) passes one that writes the
 * step rows a page is polling. The keys are the job's planned step keys.
 */
function noStep() {}

function graceDeadline(days = DOMAIN_NS_GRACE_DAYS) {
  const d = new Date(Date.now() + Number(days) * 864e5);
  return d.toISOString().slice(0, 19).replace('T', ' ');
}

/**
 * May this domain be served from our node?
 *
 * A domain we registered or transferred is ours to serve on sight: the
 * nameservers were set to ours at the registry by us, and the customer bought
 * it here. An external one has to have proved itself first.
 */
function mayPoint(domainRow) {
  if (!domainRow) return false;
  if (domainRow.source === 'external') return Boolean(domainRow.ns_verified_at);
  /*
   * A name we are registering is ours to serve only once it IS registered.
   * wintk999.com (2026-09-22) was refused by the registry for insufficient
   * balance and sat at 'pending', and a hosting order two minutes later built a
   * website, a DNS zone and a mail domain for it anyway — for a name nobody
   * owned. Provisioning already copes: the account is created without the
   * domain and the sweep builds it once the registration goes through.
   */
  if (domainRow.source === 'registered' && domainRow.status !== 'active') return false;
  /*
   * A subdomain is served on sight. The delegation check asks "has whoever
   * controls this name pointed it at us", and for `shop.example.com` that
   * question was already answered by example.com being on this account — you
   * cannot create a name under a domain you do not control. Re-asking it of the
   * subdomain itself is worse than redundant: a subdomain usually has no NS
   * records of its own at all, so the check would fail forever on a name that
   * is perfectly serveable.
   */
  return true;
}

/** Hestia says "already exists" with exit code 4. That is a success here. */
async function ignoringExists(fn) {
  try {
    await fn();
    return { ok: true };
  } catch (err) {
    if (err.code === 4) return { ok: true, existed: true };
    return { ok: false, error: err.message };
  }
}

// ---------------------------------------------------------------------------
// Adding
// ---------------------------------------------------------------------------

/**
 * Add a domain the customer already owns elsewhere.
 *
 * Refuses a name that is already on another account outright, and says so
 * without saying whose it is. A domain the same customer previously let lapse
 * out of the account is theirs to add again.
 *
 * The domain goes on the account IMMEDIATELY, whatever its nameservers say.
 * Verification is a separate step that runs straight afterwards and again from
 * the sweep — being told "added, now point it at us" is a working state a
 * customer can act on, whereas refusing the row until DNS agrees means the
 * panel cannot show them the nameservers they are supposed to be copying.
 *
 * `wantDns` and `wantMail` decide what gets built when it does verify.
 * DNS defaults ON because a domain delegated to our nameservers and given no
 * zone here resolves to nothing at all — that is not a preference, it is the
 * thing that makes the delegation work. Mail defaults OFF: creating a mail
 * domain starts accepting mail for the name and sets an expectation about MX
 * records, and a customer whose mail is at Google or Microsoft must not have
 * that done to them by a checkbox they never saw.
 *
 * @returns {Promise<{ok: true, id, domain, deadline} | {ok: false, error}>}
 */
async function addExternal({
  customer, domain: input, serviceId = null, wantDns = true, wantMail = false,
}) {
  const { domain, tld } = registrar.splitDomain(input);
  /*
   * HOSTNAME RULES, NOT REGISTRY RULES. See registrar.validateHostname for the
   * whole story; the short version is that this used to check `sld`, `sld` is
   * whatever survives stripping the extension, and stripping the wrong
   * extension made `muzahid.com.bd` unaddable with an error about hyphens.
   *
   * A name somebody already owns is not being bought, so the registry's rules
   * about what may be sold do not apply to it. What applies is whether it is a
   * valid hostname — and then whether it is delegated to us, which is checked
   * for real a moment later.
   *
   * Checked against what was TYPED, not against what splitDomain returned:
   * splitDomain strips anything outside `[a-z0-9.-]` on its way past, so
   * `muz@hid.com` would arrive here as a valid `muzhid.com` and be added
   * silently under a name nobody asked for.
   */
  const typed = String(input || '').trim().toLowerCase().replace(/\.$/, '');
  const invalid = registrar.validateHostname(typed || domain);
  if (invalid) return { ok: false, error: invalid };

  const existing = await db.one('SELECT * FROM domains WHERE domain = ? LIMIT 1', [domain]);

  if (existing && existing.customer_id !== customer.id) {
    return { ok: false, error: 'That domain is already on an account here. If it is yours, open a ticket and we will move it across.' };
  }
  if (existing && !['removed', 'cancelled'].includes(existing.status)) {
    return { ok: false, error: 'That domain is already on your account.', id: existing.id };
  }

  /*
   * A real extension, and a name that exists. The shape rules above let
   * `mysite.comm` through; a plan attached to it would wait for ever on a
   * delegation that cannot happen. See domain-reality.js.
   */
  const unreal = await reality.checkRealDomain(domain);
  if (unreal) return { ok: false, error: unreal };

  const deadline = graceDeadline();

  if (existing) {
    await db.query(
      `UPDATE domains
          SET status = 'awaiting_ns', source = 'external', service_id = ?,
              dns_enabled = ?, mail_enabled = ?,
              ns_grace_until = ?, ns_verified_at = NULL, ns_checked_at = NULL,
              ns_observed = '', pointed_at = NULL
        WHERE id = ?`,
      [serviceId, wantDns ? 1 : 0, wantMail ? 1 : 0, deadline, existing.id],
    );
  } else {
    await db.query(
      `INSERT INTO domains
         (customer_id, service_id, domain, tld, status, source, auto_renew,
          dns_enabled, mail_enabled, ns_grace_until)
       VALUES (?, ?, ?, ?, 'awaiting_ns', 'external', 0, ?, ?, ?)`,
      // auto_renew is off and stays off: we do not hold this registration and
      // cannot renew it, so a flag promising we will would be a lie.
      [customer.id, serviceId, domain, tld, wantDns ? 1 : 0, wantMail ? 1 : 0, deadline],
    );
  }

  const row = await db.one('SELECT * FROM domains WHERE domain = ? LIMIT 1', [domain]);

  await db.logActivity({
    actorType: 'customer', actorId: customer.id, action: 'domain.added_external',
    target: domain, detail: `Verify by ${deadline}`,
  });

  return { ok: true, id: row.id, domain, deadline, row };
}

/**
 * The domain on this account that `name` is a subdomain of, or null.
 *
 * THIS IS THE ONLY RELIABLE TEST for "is this a subdomain", and counting labels
 * is not it. `shop.heat6.com` and `vesopa.co.uk` both have three labels; one is
 * a subdomain and one is a registrable domain, and no amount of dot-counting
 * separates them without a public suffix list. What DOES separate them is
 * whether the customer already holds something this name sits under — which is
 * also the authorisation check, since you cannot create a name under a domain
 * you do not control.
 *
 * Walks up the labels rather than assuming the parent is everything after the
 * first dot: `shop.example.co.uk` has a three-label parent, and
 * `a.b.example.com` is a legitimate second-level subdomain.
 */
async function findParent(customer, name) {
  const labels = nameservers.normalise(name).split('.');
  for (let i = 1; i < labels.length - 1; i++) {
    const candidate = labels.slice(i).join('.');
    // eslint-disable-next-line no-await-in-loop -- at most a handful of labels
    const row = await db.one(
      // No filter on `source`: a name may legitimately sit under a subdomain
      // the account already holds (a.b.example.com under b.example.com), and
      // the closest ancestor wins because the loop walks outward from the left.
      `SELECT * FROM domains
        WHERE domain = ? AND customer_id = ? AND status <> 'removed'
        LIMIT 1`,
      [candidate, customer.id],
    );
    if (row) return row;
  }
  return null;
}

/**
 * Add a subdomain of a domain already on this account.
 *
 * No nameserver check, and no grace clock. `shop.example.com` cannot exist
 * unless somebody controls `example.com`, and that control was already
 * established when the parent was added — so the delegation question has been
 * answered and asking it again of a name that has no NS records of its own
 * would fail forever on a perfectly serveable site.
 *
 * THE PARENT HAS TO BE ON THIS ACCOUNT. That is the whole authorisation check,
 * and without it this route would let anyone create a vhost for
 * `login.somebodyelse.com` on our node — unreachable without their DNS, but
 * enough to squat the name so the real owner cannot add it, since Hestia allows
 * a given domain on exactly one account. The parent does NOT have to be
 * verified: a customer whose nameservers are still propagating, or who is
 * keeping DNS at their old provider for now, can still build the subdomain and
 * point an A record at us by hand.
 *
 * WHAT GETS CREATED. The website always — that is the point of the exercise and
 * there is nothing to decide. DNS and mail are asked for explicitly:
 *
 *   dns   a zone for the subdomain is only meaningful if the parent delegates
 *         to it, which is rare. Where the parent's zone is already here, the
 *         subdomain resolves from that zone and a second zone for it does
 *         nothing but shadow records the customer can already edit.
 *   mail  creating one silently starts accepting mail for the name and puts MX
 *         expectations on it. Nobody should get that by accident.
 */
async function addSubdomain({
  customer, subdomain: input, serviceId = null, wantDns = false, wantMail = false,
  // `build: false` records the subdomain and stops: the caller runs
  // buildSubdomain() itself, from a job the customer can watch.
  build = true, onStep = noStep,
}) {
  const name = nameservers.normalise(input);

  if (!name || !/^[a-z0-9.-]+$/.test(name) || name.includes('..')) {
    return { ok: false, error: 'That is not a valid subdomain name.' };
  }
  const labels = name.split('.');
  if (labels.length < 3 || labels.some((l) => !l.length)) {
    return { ok: false, error: 'A subdomain looks like shop.example.com — it needs a name in front of your domain.' };
  }
  if (labels.some((l) => l.length > 63 || l.startsWith('-') || l.endsWith('-'))) {
    return { ok: false, error: 'Each part of the name must be 1–63 characters and cannot start or end with a hyphen.' };
  }

  const parent = await findParent(customer, name);
  if (!parent) {
    return {
      ok: false,
      error: 'Add the main domain to your account first — a subdomain has to sit under a domain you already have here.',
    };
  }

  const existing = await db.one('SELECT * FROM domains WHERE domain = ? LIMIT 1', [name]);
  if (existing && existing.customer_id !== customer.id) {
    return { ok: false, error: 'That name is already in use here.' };
  }
  if (existing && existing.status !== 'removed') {
    return { ok: false, error: 'That subdomain is already on your account.', id: existing.id };
  }

  // Inherit the parent's service unless the caller named one, so a subdomain
  // lands on the same hosting account as the site it belongs to.
  const service = serviceId || parent.service_id || null;

  if (existing) {
    await db.query(
      `UPDATE domains
          SET status = 'active', source = 'subdomain', service_id = ?,
              dns_enabled = ?, mail_enabled = ?,
              ns_grace_until = NULL, ns_verified_at = NULL, ns_checked_at = NULL,
              ns_observed = '', pointed_at = NULL
        WHERE id = ?`,
      [service, wantDns ? 1 : 0, wantMail ? 1 : 0, existing.id],
    );
  } else {
    await db.query(
      `INSERT INTO domains
         (customer_id, service_id, domain, tld, status, source, auto_renew,
          dns_enabled, mail_enabled)
       VALUES (?, ?, ?, ?, 'active', 'subdomain', 0, ?, ?)`,
      // No tld and no auto_renew: a subdomain is not a registration, there is
      // no registry behind it and nothing to renew.
      [customer.id, service, name, '', wantDns ? 1 : 0, wantMail ? 1 : 0],
    );
  }

  const row = await db.one('SELECT * FROM domains WHERE domain = ? LIMIT 1', [name]);
  if (!build) {
    return { ok: true, id: row.id, domain: name, parent: parent.domain, row, built: null, dnsRecord: null };
  }
  return buildSubdomain({ row, parent, customer, wantDns, wantMail, onStep });
}

/**
 * The slow half of adding a subdomain: the site on the node, the A record in
 * the parent's zone. Split from addSubdomain so a job can run it and report
 * each step — see src/domain-setup.js.
 */
async function buildSubdomain({ row, parent, customer, wantDns = false, wantMail = false, onStep = noStep }) {
  const name = row.domain;
  /*
   * THE WEBSITE, THEN THE RECORD, THEN THE CERTIFICATE — in that order, and
   * the order is the point. Let's Encrypt has to reach the name to sign for
   * it, and a subdomain does not resolve anywhere until its A record is in
   * the parent's zone, which is added below. Asking for the certificate as
   * part of the build (the way a full domain does) asked before the record
   * existed, and every new subdomain came out "certificate: waits until it
   * resolves" — for a name that resolved five seconds later.
   */
  const built = await pointAtNode(row, customer, { onStep, deferSsl: true });

  /*
   * Make it resolve.
   *
   * A vhost is not a website until something answers the name, and Hestia does
   * NOT add a record to the parent zone when you add a subdomain — the first
   * version of this shipped `shop.heat6.com` with a working vhost, no DNS
   * anywhere, and a certificate request that failed because Let's Encrypt could
   * not reach a name that did not exist.
   *
   * Where the parent's zone is here, one A record fixes that and it is the
   * right place for it: the subdomain lives IN the parent zone, which is
   * exactly why it does not need a zone of its own. The address is copied from
   * the parent's own A record rather than read from config, so the subdomain
   * lands wherever the parent already points, on any node.
   *
   * Where the parent's zone is elsewhere, there is nothing we can write and the
   * customer adds the record at their provider — `dnsRecord` says which.
   */
  let dnsRecord = { ok: false, pointAt: POINT_HOSTNAME, reason: 'the main domain is not pointed at us' };
  if (!wantDns) {
    onStep('record', 'running', `Adding an A record for it in ${parent.domain}'s zone`);
    try {
      /*
       * BOTH conditions, and the delegation is the one that decides it.
       *
       * A zone can exist on this node for a domain whose nameservers are still
       * at the old provider — that is the normal state for the first few hours
       * after a customer adds a domain. Writing a record into a zone nobody is
       * asking is not wrong, but it resolves nothing, and telling the customer
       * their subdomain is live on the strength of it would be a lie. So the
       * record is only treated as the answer when the parent is verified;
       * otherwise the customer is told to point it themselves.
       */
      const parentVerified = Boolean(parent.ns_verified_at);
      const parentZone = parentVerified
        && await hestia.dnsDomainExists({ username: customer.hestia_user, domain: parent.domain });
      if (parentZone) {
        const records = await hestia.listDnsRecords({ username: customer.hestia_user, domain: parent.domain });
        const apex = records.find((r) => r.type === 'A' && (r.name === '@' || r.name === ''));
        const label = name.slice(0, -(parent.domain.length + 1));
        const already = records.some((r) => r.name === label && ['A', 'CNAME'].includes(r.type));

        if (already) {
          dnsRecord = { ok: true, existed: true, name: label };
        } else if (apex) {
          await hestia.addDnsRecord({
            username: customer.hestia_user,
            domain: parent.domain,
            name: label,
            type: 'A',
            value: apex.value,
          });
          dnsRecord = { ok: true, name: label, value: apex.value };
        } else {
          dnsRecord = { ok: false, pointAt: POINT_HOSTNAME, reason: 'the main domain has no A record to copy' };
        }
      }
    } catch (err) {
      // Never fatal. The site exists; it just is not reachable yet, and that is
      // a thing the customer can be told and can fix at their own provider.
      dnsRecord = { ok: false, pointAt: POINT_HOSTNAME, reason: err.message };
    }

    /*
     * Last word goes to the public DNS.
     *
     * Whether we managed to write a record is OUR bookkeeping; whether the name
     * resolves to this node is the thing the customer actually cares about, and
     * the two come apart in both directions. A subdomain can already be pointed
     * here — the customer set it up at their provider before adding it, or it
     * was live on this node all along — in which case telling them to go and
     * point something is nonsense: there is nothing for them to do, and asking
     * makes the panel look like it cannot see its own state.
     *
     * So if it resolves to us, it is pointed, whatever we did or did not write.
     */
    if (!dnsRecord.ok) {
      const live = await nameservers.pointsAtUs(name, POINT_HOSTNAME);
      if (live.pointed) {
        dnsRecord = { ok: true, alreadyPointed: true, addresses: live.addresses };
      }
    }
    if (dnsRecord.ok) {
      onStep('record', 'ok', dnsRecord.existed ? 'It was already there'
        : dnsRecord.alreadyPointed ? 'The name already resolves here'
          : `${dnsRecord.name} → ${dnsRecord.value}`);
    } else {
      onStep('record', 'skipped', `Not added — ${dnsRecord.reason}. Point it here with an A record at your DNS provider.`);
    }
  }

  if (built.pointed) {
    // Our nameserver answers for the parent zone the instant the record is
    // written, so this does not wait on propagation; a name that still fails
    // to resolve is one whose DNS is elsewhere, and issueSsl says so.
    onStep('ssl', 'running', "Let's Encrypt proves the name reaches us, then signs — usually ten to fifteen seconds");
    const ssl = await issueSsl(row, customer, { force: true });
    built.ssl = Boolean(ssl.ok);
    built.sslError = ssl.ok ? '' : (ssl.message || explainSslError(ssl.error || ''));
    if (ssl.ok) onStep('ssl', 'ok', `https://${name} — renews itself`);
    else onStep('ssl', dnsRecord.ok ? 'failed' : 'skipped', built.sslError);
  } else {
    onStep('ssl', 'skipped', 'Nothing to certify without a website');
  }

  await db.logActivity({
    actorType: 'customer', actorId: customer.id, action: 'domain.added_subdomain',
    target: name,
    detail: `Under ${parent.domain}. web${wantDns ? ' + dns' : ''}${wantMail ? ' + mail' : ''}`
      + (dnsRecord.ok ? `; A record ${dnsRecord.name} added to the parent zone` : `; no A record (${dnsRecord.reason})`),
    ok: built.pointed,
  });

  return {
    ok: true, id: row.id, domain: name, parent: parent.domain, row, built, dnsRecord,
  };
}

// ---------------------------------------------------------------------------
// Verifying
// ---------------------------------------------------------------------------

/**
 * Ask the public DNS where this domain points, record the answer, and act on it.
 *
 * TWO WAYS TO POINT AT US, and which one applies is not a preference — it is a
 * property of the name.
 *
 *   ns   The domain is delegated to our nameservers. We answer for the whole
 *        zone, so DNS is ours to edit and MX is ours to set. This is the full
 *        arrangement and the one a domain registered here always has.
 *
 *   a    An A record aims the name at this node while DNS stays wherever it
 *        already was. The website and the certificate work identically; the
 *        zone is not ours, so the DNS editor is off and mail needs records the
 *        customer adds at their own provider.
 *
 * A SUBDOMAIN IS ONLY EVER 'a', AND THAT IS THE BUG THIS FIXES. Delegation is a
 * property of a zone. Asking whether `shop.example.com` is delegated to us is
 * asking a question a subdomain has no way to answer — it normally has no NS
 * records at all — so `resolveNs` fails, and the old code read that failure as
 * "not pointing at us". A subdomain that was resolving to this node perfectly
 * was shown "Waiting for your nameservers", with a nameserver form underneath
 * it that could never have helped. Subdomains are checked by address, full
 * stop, and never by delegation.
 *
 * For a full domain the delegation is tried FIRST, because it is the better
 * arrangement and the answer decides whether we may offer DNS and mail. Only if
 * that fails do we ask whether an A record has been pointed here anyway.
 *
 * Both observations are written down even on a failure. "We can see
 * ns1.theirhost.com" and "we can see 3.72.113.21" are each the difference
 * between a customer fixing it in two minutes and opening a ticket.
 *
 * @returns {Promise<{matched: boolean, method: string, nameservers: string[],
 *                    addresses: string[], error: string, pointed?: object}>}
 */
async function verify(domainRow, { customer = null, onStep = noStep } = {}) {
  const isSubdomain = domainRow.source === 'subdomain';

  let ns = { matched: false, nameservers: [], extras: [], error: '', serverFailure: false };
  let healed = null;

  if (!isSubdomain) {
    onStep('delegation', 'running', 'Asking the registry and the public resolvers, not our own records');
    ns = await nameservers.check(domainRow.domain);
    if (ns.matched && ns.dead && ns.dead.length) {
      onStep('delegation', 'ok', `Delegated to us — but ${ns.dead.join(', ')} in the delegation does not exist; replace it with ${NAMESERVERS[1] || NAMESERVERS[0]} at the registrar`);
    } else if (ns.matched) {
      onStep('delegation', 'ok', `Delegated to us${ns.via === 'registry' ? ' at the registry' : ''}`);
    } else if (ns.unregistered) {
      onStep('delegation', 'failed', 'The registry says this name is not registered');
    } else if (ns.nameservers.length) {
      onStep('delegation', 'skipped', `Delegated to ${ns.nameservers.slice(0, 2).join(', ')}${ns.nameservers.length > 2 ? '…' : ''} — not us yet`);
    } else {
      onStep('delegation', 'skipped', ns.error || 'No nameservers found for it yet');
    }

    /*
     * ------------------------------------------------------------------
     * THE DEADLOCK, BROKEN HERE.
     * ------------------------------------------------------------------
     * A domain registered through us has its nameservers set to ours at the
     * registry by us — there is no customer step and nothing to prove. But
     * until a zone exists on the node, ns1.vesopa.com answers REFUSED for it,
     * public resolvers turn that into SERVFAIL, and this check fails. The old
     * code then returned early, so the zone was never created, so the check
     * failed again on the next sweep, forever. vesopa.site lived in that state
     * with a perfect delegation and nothing on the node at all.
     *
     * So when the lookup fails with a SERVER failure (not "does not exist"),
     * the domain is one we may serve on sight, and OUR OWN nameserver confirms
     * it is not holding the zone — build it, then ask the public internet
     * again. One retry, never a loop.
     *
     * AN EXTERNAL DOMAIN IS NO LONGER EXCLUDED, and that is the sheve.site fix.
     *
     * It used to be, and the reasoning was sound while a SERVFAIL was all we
     * had: it may be delegated to us and waiting for exactly this, or it may be
     * broken at a registrar we have nothing to do with, and creating zones for
     * names nobody has pointed at us on the strength of a failed lookup is not
     * a thing to do automatically.
     *
     * `nameservers.check()` reads the delegation out of the REGISTRY now, so
     * the ambiguity is gone. `ns.matched` with `ns.serverFailure` means the
     * registry sends the internet to ns1/ns2.vesopa.com and our nameservers are
     * not answering — which is not ambiguous at all. It is proof of control
     * (only whoever holds the domain can set that delegation) and the thing
     * that is broken is ours to fix. sheve.site sat in exactly that state:
     * correctly delegated, "Could not read the nameservers (ESERVFAIL)" on the
     * screen, and a four-day clock running to drop it off the account.
     *
     * `mayPoint` still guards everything else. This is the one case it gets
     * wrong, and only because it cannot be satisfied until the zone exists.
     */
    if (ns.serverFailure && (ns.matched || mayPoint(domainRow))) {
      const ours = await nameservers.servedByUs(domainRow.domain);
      if (ours.reachable && !ours.served) {
        const owner = customer
          || await db.one('SELECT * FROM customers WHERE id = ? LIMIT 1', [domainRow.customer_id]);
        healed = await pointAtNode(domainRow, owner, { resolvesHere: false, force: true });
        if (healed.pointed) {
          await db.logActivity({
            actorType: 'system', action: 'domain.zone_created', target: domainRow.domain,
            detail: 'Delegated to us with no zone here — created it so the delegation can resolve.',
          });
          // Ask again with the zone in place. A brand-new zone is answered by
          // our own nameserver immediately; the recursive resolvers this check
          // uses may still be holding the SERVFAIL for a minute or two, which
          // is fine — the next sweep picks it up.
          ns = await nameservers.check(domainRow.domain);
        }
      }
    }
  }

  /*
   * THE ADDRESS IS CHECKED EVERY TIME, including when the delegation already
   * matched, and that is not belt-and-braces — the NS check alone produces
   * false positives.
   *
   * `resolveNs` returns the NS records held by whichever server actually
   * answers for the name, which is NOT the same as the delegation recorded at
   * the registry. A zone on somebody else's box can list our nameservers quite
   * happily. That is not hypothetical: heat6.com was delegated to
   * ns1.onzep.uk, whose copy of the zone named ns1/ns2.vesopa.com — so the
   * delegation check passed while every visitor was being served by the old
   * server. Verified, and pointing somewhere else.
   *
   * So delegation decides whether DNS is ours to run; the ADDRESS decides
   * whether we are actually serving the site, and a certificate can only be
   * issued on the strength of the second one.
   *
   * Never throws: "we could not tell" comes back as not-pointing.
   */
  onStep('address', 'running', `Does ${domainRow.domain} answer with this server's address?`);
  const ip = await nameservers.pointsAtUs(domainRow.domain, POINT_HOSTNAME);

  const method = ns.matched ? 'ns' : (ip.pointed ? 'a' : '');
  const matched = Boolean(method);
  const resolvesHere = ip.pointed;
  if (ip.pointed) onStep('address', 'ok', `Yes — ${ip.addresses.join(', ')}`);
  else if (ns.matched) onStep('address', 'skipped', 'Not yet — the delegation is right and the zone is about to exist, so it will');
  else onStep('address', 'skipped', ip.addresses.length ? `It answers with ${ip.addresses.join(', ')}, which is not us` : 'It does not resolve anywhere yet');

  /*
   * `ns_observed` and `ip_observed` are only overwritten when that lookup
   * actually answered.
   *
   * A resolver timeout, or a domain that has stopped resolving entirely, is not
   * evidence that it points nowhere — and blanking the field on those turns the
   * one useful thing we can tell a customer into "nothing", in both the panel
   * and the removal email. The last answer we genuinely got beats no answer.
   */
  await db.query(
    `UPDATE domains
        SET ns_checked_at = NOW(),
            ns_observed = CASE WHEN ? = 1 THEN ? ELSE ns_observed END,
            ip_observed = CASE WHEN ? = 1 THEN ? ELSE ip_observed END,
            verify_method = ?,
            ns_verified_at = CASE WHEN ? = 1 THEN COALESCE(ns_verified_at, NOW()) ELSE NULL END
      WHERE id = ?`,
    [
      ns.nameservers.length ? 1 : 0,
      ns.nameservers.join(' ').slice(0, 400),
      ip.addresses.length ? 1 : 0,
      ip.addresses.join(' ').slice(0, 200),
      method,
      matched ? 1 : 0,
      domainRow.id,
    ],
  );

  const result = {
    matched,
    method,
    resolvesHere,
    nameservers: ns.nameservers,
    addresses: ip.addresses,
    // Where the delegation came from — 'registry' is the record itself,
    // 'resolver' is what a recursive resolver happened to answer. Reported so
    // the panel can say "delegated to us, still propagating" rather than
    // implying the customer has something left to do.
    via: ns.via || '',
    resolved: ns.resolved || [],
    // The registry says this name is not registered at all. A different problem
    // from a delegation pointing elsewhere, and a different thing to say.
    unregistered: Boolean(ns.unregistered),
    error: ns.error || '',
    // Set when this call created the zone that was missing. The panel says so
    // rather than reporting a bare "not yet" for a check that just did real
    // work — "we have set it up, DNS is catching up" is a true and much less
    // alarming sentence than the same failure twice.
    healed: healed ? { built: Boolean(healed.pointed), reason: healed.reason || '' } : null,
  };

  /*
   * EMAIL-ONLY. A domain whose MX points at us gets its mail here whatever its
   * website does — a customer who hosts their site elsewhere and wants only
   * mailboxes with us has nothing else to point. Verified on the same terms
   * as the website: what the public DNS answers, not what anybody claims.
   *
   * Checked for every domain, not only unmatched ones, so a domain that IS
   * pointed at us but has its MX at Google is known to be delivering its mail
   * elsewhere and the Email page can say so.
   */
  let mx = { pointed: false, exchangers: [], others: [], exclusive: false };
  if (!isSubdomain) {
    onStep('mx', 'running', `Where does ${domainRow.domain}'s email get delivered?`);
    mx = await nameservers.mxPointsAtUs(domainRow.domain, MAIL_HOSTNAME);
    await db.query(
      `UPDATE domains
          SET mx_observed = ?,
              mx_verified_at = CASE WHEN ? = 1 THEN COALESCE(mx_verified_at, NOW()) ELSE NULL END
        WHERE id = ?`,
      [mx.exchangers.map((e) => e.host).join(' ').slice(0, 400), mx.pointed ? 1 : 0, domainRow.id],
    );
    if (mx.pointed && mx.exclusive) onStep('mx', 'ok', `Here — MX ${mx.exchangers.map((e) => e.host).join(', ')}`);
    else if (mx.pointed) onStep('mx', 'ok', `Here, and also at ${mx.others.join(', ')} — remove those or mail is split`);
    else if (mx.exchangers.length) onStep('mx', 'skipped', `At ${mx.others.join(', ')} — not us. Point the MX at ${MAIL_HOSTNAME} to have email here`);
    else onStep('mx', 'skipped', `No MX record yet — point one at ${MAIL_HOSTNAME} to have email here`);
  }
  result.mx = mx;

  if (!matched && mx.pointed) {
    /*
     * Mail here, website elsewhere: the domain is in use and leaves the
     * waiting room — a domain delivering somebody's email must never be put
     * on the four-day clock and dropped. What is built is the mail domain,
     * and only that; no zone, no site, no certificate.
     */
    await db.query(
      "UPDATE domains SET status = 'active', ns_grace_until = NULL WHERE id = ? AND status = 'awaiting_ns'",
      [domainRow.id],
    );
    const owner = customer
      || await db.one('SELECT * FROM customers WHERE id = ? LIMIT 1', [domainRow.customer_id]);
    const wantsMail = domainRow.mail_enabled === undefined || Number(domainRow.mail_enabled) === 1;
    let mailBuilt = { ok: false, reason: '' };
    if (!owner?.hestia_user) {
      mailBuilt = { ok: false, reason: 'No hosting on this account yet.' };
      onStep('mail', 'skipped', 'No hosting on this account yet');
    } else if (!wantsMail) {
      mailBuilt = { ok: false, reason: 'Email was not asked for on this domain.' };
      onStep('mail', 'skipped', 'Email was switched off for this domain when it was added');
    } else {
      onStep('mail', 'running', 'A mail domain with DKIM, ready for mailboxes');
      const built = await ignoringExists(() => hestia.addMailDomain({ username: owner.hestia_user, domain: domainRow.domain }));
      await hestia.removeWebmailAlias({ username: owner.hestia_user, domain: domainRow.domain }).catch(() => {});
      mailBuilt = { ok: built.ok, reason: built.ok ? '' : explainNodeError(built.error || '') };
      if (built.ok) onStep('mail', 'ok', built.existed ? 'It was already there' : 'Ready — create mailboxes from the Email page, and add the records it shows');
      else onStep('mail', 'failed', mailBuilt.reason);
    }
    await db.logActivity({
      actorType: 'system', action: 'domain.mail_verified', target: domainRow.domain,
      detail: `MX ${mx.exchangers.map((e) => e.host).join(', ')}; ${mailBuilt.ok ? 'mail domain on the node' : mailBuilt.reason}`,
    });
    return { ...result, mailOnly: true, mailBuilt };
  }

  if (!matched) return result;

  /*
   * A verified domain leaves the waiting room. `pending` is left alone: that
   * one is mid-registration and provisionDomain owns its status.
   */
  if (domainRow.status === 'awaiting_ns') {
    await db.query("UPDATE domains SET status = 'active' WHERE id = ? AND status = 'awaiting_ns'", [domainRow.id]);
  }

  const owner = customer
    || await db.one('SELECT * FROM customers WHERE id = ? LIMIT 1', [domainRow.customer_id]);

  const pointed = await pointAtNode(
    { ...domainRow, ns_verified_at: new Date(), verify_method: method },
    owner,
    // Do not spend a slow Let's Encrypt call, or a slice of its rate limit, on
    // a name that demonstrably does not resolve here yet. The challenge would
    // fail by definition.
    { resolvesHere, onStep },
  );

  await db.logActivity({
    actorType: 'system', action: 'domain.verified', target: domainRow.domain,
    detail: `by ${method === 'ns' ? 'nameservers' : 'A record'}; `
      + (pointed.pointed ? 'serving from the node' : pointed.reason || 'not served'),
  });

  return { ...result, pointed };
}

/**
 * Create everything on the node that serving this domain needs.
 *
 * Every step tolerates "already exists", because this runs again on every
 * successful verification and a domain that is already set up must not report a
 * failure for being set up. SSL is best-effort and last: a certificate that
 * cannot be issued yet is a retry button in the panel, not a broken site.
 */
async function pointAtNode(domainRow, customer, {
  resolvesHere = null, force = false, onStep = noStep,
  // `deferSsl`: build the site and stop. The caller has something to do first
  // that decides whether a certificate can be issued at all — a subdomain's A
  // record, which does not exist until the site does.
  deferSsl = false,
} = {}) {
  /*
   * `force` exists for the one case the gate below gets wrong: a domain that
   * cannot be verified UNTIL it is built.
   *
   * We are its nameservers. A resolver asking ns1.vesopa.com for a zone we have
   * not created gets REFUSED, so the public answer is SERVFAIL, so verification
   * fails, so we never create the zone. Nothing in that loop moves on its own,
   * and the customer's registrar shows a delegation that is entirely correct.
   *
   * Building the zone is the cheap half and it is safe to do unasked: a zone
   * for a name that turns out not to be delegated to us serves nobody and costs
   * nothing. The EXPENSIVE half stays gated exactly as it was — `resolvesHere`
   * still decides whether a certificate is attempted, so a forced build cannot
   * burn a Let's Encrypt rate limit on a name that does not resolve here.
   */
  if (!force && !mayPoint(domainRow)) {
    return { pointed: false, reason: 'Not verified as pointing at us yet.' };
  }
  if (!customer?.hestia_user) {
    /*
     * No hosting account to serve it from. Not an error and not a half-finished
     * job: a domain can be registered here and hosted anywhere, and building
     * them a Hestia account they have not bought would be creating hosting
     * without a payment — the exact thing the order flow now refuses to do.
     */
    onStep('web', 'skipped', 'No hosting on this account yet');
    return { pointed: false, reason: 'No hosting on this account yet.' };
  }

  const username = customer.hestia_user;
  const domain = domainRow.domain;
  const steps = [];

  /*
   * A full domain gets all three; a subdomain gets what it asked for, and the
   * website either way.
   *
   * `dns_enabled` and `mail_enabled` default to 1 in the schema, so a domain
   * row written before those columns existed still behaves exactly as it did.
   * Only the subdomain flow writes zeroes.
   */
  const wantsDns = domainRow.dns_enabled === undefined || Number(domainRow.dns_enabled) === 1;
  const wantsMail = domainRow.mail_enabled === undefined || Number(domainRow.mail_enabled) === 1;

  // The zone first: our nameservers answer for this name now, and without a
  // zone on the node they answer with nothing at all.
  const report = (key, result, doneText) => {
    if (result.ok) onStep(key, 'ok', result.existed ? 'It was already there' : doneText);
    else onStep(key, 'failed', explainNodeError(result.error || ''));
  };

  if (wantsDns) {
    onStep('zone', 'running', 'So our nameservers have something to answer with');
    const dns = await ignoringExists(() => hestia.addDnsDomain({ username, domain }));
    steps.push({ step: 'dns', ...dns });
    report('zone', dns, 'A zone with the usual records, served by ns1 and ns2');
  }
  onStep('web', 'running', 'A virtual host on the node, with a holding page until you upload');

  /*
   * ASK BEFORE CREATING, rather than creating and interpreting the failure.
   *
   * `ignoringExists` swallows Hestia's code 4 ("already exists"), which is the
   * right answer when re-running a build on a name the account already serves.
   * But Hestia does not always answer 4: on a package whose web-domain
   * allowance is already spent BY THIS VERY DOMAIN, `v-add-domain` answers
   * code 8, "the package limit was reached".
   *
   * So re-running a build on a working site reported "the website could not be
   * created on the server" — for a website that was sitting there, serving,
   * with a valid certificate. Measured on arpi.site: the vhost existed and had
   * SSL, and every attempt to attach it to its plan failed with a limit error
   * about the domain that was occupying the limit.
   *
   * Checking first is also simply more honest: a genuine limit breach on a NEW
   * domain must still fail loudly, and blanket-swallowing code 8 would hide it.
   */
  const alreadyServed = await hestia.webDomainExists({ username, domain }).catch(() => false);

  if (alreadyServed) {
    steps.push({ step: 'web', ok: true, existed: true });
    onStep('web', 'ok', 'It was already there');
  } else {
    /*
     * `addWebDomain` is v-add-domain, which creates the zone and the mail domain
     * as well — harmless when both were wanted, and exactly wrong when they were
     * not. A name that opted out of either gets the narrow v-add-web-domain.
     */
    const webOnly = !wantsDns || !wantsMail;
    const web = await ignoringExists(() => (webOnly
      ? hestia.addWebsite({ username, domain })
      : hestia.addWebDomain({ username, domain })));
    steps.push({ step: 'web', ...web });
    report('web', web, 'Created — files go in public_html');
  }

  if (wantsMail) {
    onStep('mail', 'running', 'A mail domain with DKIM, ready for mailboxes');
    const mail = await ignoringExists(() => hestia.addMailDomain({ username, domain }));
    steps.push({ step: 'mail', ...mail });
    report('mail', mail, 'Ready — create mailboxes from the Email page');
  }

  const web = steps.find((s) => s.step === 'web');
  let ssl = { ok: false, error: 'The website was not created, so there was nothing to certify.' };

  /*
   * A certificate is only worth asking for if the name actually resolves here.
   *
   * Let's Encrypt validates by fetching the name over the public internet, so
   * for anything that does not point at this node the request cannot succeed —
   * it just takes ninety seconds to fail, and spends one of the handful of
   * attempts the rate limit allows per domain per hour. The caller usually
   * knows the answer already (verify has just looked it up); when it does not,
   * this looks it up rather than guessing.
   */
  if (web.ok && deferSsl) {
    // Not attempted, not recorded, not reported — and not LOOKED UP either:
    // a public resolver asked about a name whose record is about to be
    // written may cache the "no such name" for an hour. The caller does the
    // certificate next, after the record exists.
    await db.query('UPDATE domains SET pointed_at = COALESCE(pointed_at, NOW()) WHERE id = ?', [domainRow.id]);
    return { pointed: true, ssl: false, sslError: '', reason: '', steps, deferred: true };
  }

  const reachable = resolvesHere === null
    ? (await nameservers.pointsAtUs(domain, POINT_HOSTNAME)).pointed
    : resolvesHere;

  if (web.ok && !reachable) {
    ssl = {
      ok: false,
      error: 'The name does not resolve to this server yet, so a certificate cannot be issued. '
        + 'It is requested automatically once it does.',
    };
    onStep('ssl', 'skipped', 'Waits until the name resolves here — then it is requested on its own');
  } else if (web.ok) {
    onStep('ssl', 'running', "Let's Encrypt proves the name reaches us, then signs — usually ten to fifteen seconds");
    /*
     * NO `www.` FOR A SUBDOMAIN. `www.shop.example.com` is a name nobody
     * publishes, and a certificate request fails as a whole if any name in it
     * fails validation — so asking for it would take the subdomain's own
     * certificate down with it, every time.
     *
     * `mail: false` always. See hestia.enableSSL: that flag does not add the
     * mail name, it REPLACES the target with it. Mail is served under one
     * hostname for every customer and needs no certificate per domain.
     */
    ssl = await ignoringExists(() => hestia.enableSSL({
      username,
      domain,
      aliases: isSubdomain(domainRow) ? '' : `www.${domain}`,
      mail: false,
    }));
    if (ssl.ok) onStep('ssl', 'ok', `https://${domain} — renews itself`);
    else onStep('ssl', 'failed', explainSslError(ssl.error));
  } else {
    onStep('ssl', 'skipped', 'Nothing to certify without a website');
  }
  steps.push({ step: 'ssl', ...ssl });
  await recordSsl(domainRow.id, ssl);

  if (web.ok) {
    await db.query('UPDATE domains SET pointed_at = COALESCE(pointed_at, NOW()) WHERE id = ?', [domainRow.id]);
  }

  return {
    pointed: web.ok,
    ssl: ssl.ok,
    sslError: ssl.ok ? '' : explainSslError(ssl.error),
    // WHY it did not get built, in a sentence the customer can act on. Without
    // this the caller falls back to "the website could not be created on the
    // server — open a ticket", which is the wrong instruction for the commonest
    // cause by far. Measured on sheve.site: correctly delegated, correctly
    // added, and unbuildable because the account's plan allows one website and
    // arpi.site is using it. A ticket cannot fix that; a bigger plan can.
    reason: web.ok ? '' : explainNodeError(web.error),
    steps,
  };
}

/**
 * Turn a Hestia refusal into something with a next step in it.
 *
 * The same job `explainSslError` does for Let's Encrypt. These strings come
 * from an exit-code table and are written for an administrator — "The package
 * limit was reached." is accurate, tells a customer nothing about which limit
 * or what to do, and reads like a fault in our software.
 */
function explainNodeError(raw) {
  const text = String(raw || '').toLowerCase();
  if (!text) return '';
  if (text.includes('package limit')) {
    return 'Your hosting plan is already using all the websites it allows, so there is no room on it '
      + 'for another domain. Moving up a plan makes room immediately — or take a domain off this plan '
      + 'first and this will go straight through.';
  }
  if (text.includes('disk') || text.includes('quota')) {
    return 'The hosting account is out of disk space, so nothing further can be created on it. '
      + 'Free some space or move up a plan, then try again.';
  }
  if (text.includes('suspend')) {
    return 'The hosting account is suspended, so nothing can be created on it. '
      + 'Settle any outstanding invoice, or open a ticket and we will look.';
  }
  return raw;
}

/**
 * Turn a Let's Encrypt failure into a sentence a customer can act on.
 *
 * Hestia surfaces these as an exit code and one line of ACME prose. Left raw
 * they read as our software breaking, when nearly all of them are one of three
 * ordinary situations with an obvious next step.
 */
function explainSslError(raw) {
  const text = String(raw || '').toLowerCase();
  if (!text) return '';
  if (text.includes('rate limit') || text.includes('too many certificates')) {
    return 'Let\'s Encrypt is rate-limiting this domain after too many attempts. '
      + 'It clears by itself — try again in an hour.';
  }
  if (text.includes('dns problem') || text.includes('nxdomain') || text.includes("doesn't exist")) {
    return 'The name does not resolve to this server yet. DNS changes can take a few hours; '
      + 'once it points here, press the button again.';
  }
  if (text.includes('challenge') || text.includes('unauthorized') || text.includes('timeout')) {
    return 'Let\'s Encrypt could not reach this site to prove you own it. '
      + 'That is nearly always DNS still propagating — try again shortly.';
  }
  return raw;
}

/**
 * Write down what happened to the certificate.
 *
 * This is the half that was missing. pointAtNode has always ASKED for a
 * certificate; it threw the answer away, so nothing knew whether one existed,
 * nothing ever retried a failure, and the panel could not show a padlock or
 * explain its absence. A customer's only signal was the browser's.
 */
async function recordSsl(domainId, ssl, cert = null) {
  const status = ssl.ok ? 'active' : 'failed';
  await db.query(
    `UPDATE domains
        SET ssl_status = ?,
            ssl_checked_at = NOW(),
            ssl_issued_at = CASE WHEN ? = 'active' THEN COALESCE(ssl_issued_at, NOW()) ELSE ssl_issued_at END,
            ssl_expires_at = COALESCE(?, ssl_expires_at),
            ssl_self_signed = ?,
            ssl_error = ?
      WHERE id = ?`,
    [
      status, status,
      cert?.expires_at ? new Date(cert.expires_at).toISOString().slice(0, 19).replace('T', ' ') : null,
      cert?.self_signed ? 1 : 0,
      ssl.ok ? '' : explainSslError(ssl.error).slice(0, 300),
      domainId,
    ],
  );
}

/**
 * Is this domain's certificate actually good right now, and may the customer
 * ask for a new one?
 *
 * ---------------------------------------------------------------------------
 * "HAS A CERTIFICATE" AND "HAS A WORKING CERTIFICATE" ARE DIFFERENT QUESTIONS
 * ---------------------------------------------------------------------------
 * `ssl_status` records the first; it stays 'active' for a certificate that
 * expired months ago, and it is 'active' for the self-signed placeholder Hestia
 * installs when Let's Encrypt has never succeeded. Gating the reissue button on
 * it gets the answer wrong in both directions at once:
 *
 *   it HIDES the button from the person whose certificate lapsed on Tuesday
 *   and who is looking at a browser warning right now, and
 *
 *   it OFFERS the button to the person whose certificate is fine, who presses
 *   it, and spends one of the five issuances Let's Encrypt allows for that name
 *   per week replacing a certificate that had eleven weeks left.
 *
 * So the question is answered from the expiry date. `mayIssue` is false only
 * when we have positively established a valid, non-self-signed certificate with
 * more than the renewal window left. Anything we do not know — a node we could
 * not reach, an expiry we never read — leaves the button available, because
 * being able to retry something that turns out not to have needed it is a much
 * smaller problem than not being able to fix a site that is down.
 */
const SSL_RENEW_WINDOW_DAYS = 30;

function sslState(domainRow) {
  const expiresAt = domainRow?.ssl_expires_at ? new Date(domainRow.ssl_expires_at) : null;
  const daysLeft = expiresAt && !Number.isNaN(expiresAt.getTime())
    ? Math.floor((expiresAt.getTime() - Date.now()) / 864e5)
    : null;
  const selfSigned = Number(domainRow?.ssl_self_signed) === 1;
  const valid = daysLeft !== null && daysLeft > 0 && !selfSigned;

  return {
    status: domainRow?.ssl_status || 'none',
    expires_at: expiresAt,
    days_left: daysLeft,
    self_signed: selfSigned,
    valid,
    expired: daysLeft !== null && daysLeft <= 0,
    // Inside the renewal window it is legitimate to ask early, so the button
    // comes back a month before expiry rather than on the day.
    mayIssue: !valid || daysLeft <= SSL_RENEW_WINDOW_DAYS,
    why: valid && daysLeft > SSL_RENEW_WINDOW_DAYS
      ? `This certificate is valid for another ${daysLeft} days and renews itself automatically. `
        + 'There is nothing to do.'
      : '',
  };
}

/**
 * Ask for a certificate now, for one domain.
 *
 * Separate from pointAtNode because retrying is its own act with its own
 * button. The overwhelmingly common case is "DNS had not propagated when we
 * first tried", and making that self-service removes an entire category of
 * ticket — the same reasoning as the service page's SSL retry, except that
 * this one reaches domains that are not attached to a service at all, which
 * the old button could not.
 */
async function issueSsl(domainRow, customer, { force = false } = {}) {
  if (!customer?.hestia_user) {
    return { ok: false, error: 'There is no hosting account to install a certificate on.' };
  }
  if (!mayPoint(domainRow)) {
    return { ok: false, error: 'This domain is not pointing at us yet, so a certificate cannot be issued for it.' };
  }

  /*
   * A certificate that is already good is not reissued.
   *
   * Let's Encrypt allows five duplicate certificates per name per week. Every
   * needless reissue spends one, and the account that runs out is locked out at
   * exactly the moment it has a real emergency. The state is read fresh from
   * the node rather than from our row, because the row may be a week old and
   * the customer pressing this button has usually just changed something.
   *
   * `force` exists for support, not for the panel.
   */
  if (!force) {
    const cert = await hestia.webDomainCert({ username: customer.hestia_user, domain: domainRow.domain })
      .catch(() => ({ ok: false }));
    if (cert.ok && cert.expires_at) {
      await recordSsl(domainRow.id, { ok: true }, cert);
      const state = sslState({
        ssl_status: 'active',
        ssl_expires_at: cert.expires_at,
        ssl_self_signed: cert.self_signed ? 1 : 0,
      });
      if (!state.mayIssue) {
        return {
          ok: true,
          skipped: true,
          alreadyValid: true,
          expires_at: cert.expires_at,
          days_left: cert.days_left,
          message: state.why,
        };
      }
    }
  }

  /*
   * Asked again here rather than trusted from the row. The button is pressed by
   * somebody who has just changed their DNS, so the stored answer is precisely
   * the one most likely to be out of date — in both directions.
   */
  const live = await nameservers.pointsAtUs(domainRow.domain, POINT_HOSTNAME);
  if (!live.pointed) {
    const seen = live.addresses.length ? ` It currently answers with ${live.addresses.join(', ')}.` : '';
    await recordSsl(domainRow.id, {
      ok: false,
      error: `${domainRow.domain} does not resolve to this server yet.${seen}`,
    });
    return {
      ok: false,
      error: `${domainRow.domain} does not resolve to this server yet, and Let's Encrypt has to `
        + `reach it to prove you own it.${seen} Point it here first, then try again.`,
    };
  }

  const result = await ignoringExists(() => hestia.enableSSL({
    username: customer.hestia_user,
    domain: domainRow.domain,
    aliases: isSubdomain(domainRow) ? '' : `www.${domainRow.domain}`,
    mail: false,
  }));

  // Read the new certificate's dates back so the panel can say when it expires
  // rather than only that it exists — and so the guard above has something to
  // work with next time.
  const cert = result.ok
    ? await hestia.webDomainCert({ username: customer.hestia_user, domain: domainRow.domain })
      .catch(() => null)
    : null;

  await recordSsl(domainRow.id, result, cert);
  return {
    ...result,
    expires_at: cert?.expires_at || null,
    days_left: cert?.days_left ?? null,
    message: result.ok ? '' : explainSslError(result.error),
  };
}

/**
 * What certificate does this domain have RIGHT NOW?
 *
 * Read from the node, then written down. The stored value is what the domain
 * list renders — one query rather than one Hestia call per row — and this
 * refreshes it whenever somebody is actually looking at that domain's page.
 *
 * A node we cannot reach returns the last thing we knew rather than "none":
 * claiming a live site has no certificate because our own API call timed out
 * would send customers to reissue certificates they already have, straight
 * into a Let's Encrypt rate limit.
 */
async function refreshSsl(domainRow, customer) {
  const stored = {
    status: domainRow.ssl_status || 'none',
    error: domainRow.ssl_error || '',
    issued_at: domainRow.ssl_issued_at || null,
  };
  if (!customer?.hestia_user || !hestia.isLive()) return stored;

  try {
    const live = await hestia.webDomainSsl({
      username: customer.hestia_user,
      domain: domainRow.domain,
    });
    // A certificate that is present wins outright. Absent means "failed" only
    // if we have a recorded reason; otherwise it has simply never been asked
    // for, and "none" is the honest word for that.
    const status = live.ssl ? 'active' : (domainRow.ssl_error ? 'failed' : 'none');

    // The dates as well as the flag. Without these the panel can say a domain
    // has a certificate but never that it expires on Thursday, which is the
    // half a customer can act on — see sslState().
    const cert = live.ssl
      ? await hestia.webDomainCert({ username: customer.hestia_user, domain: domainRow.domain })
        .catch(() => null)
      : null;

    await db.query(
      `UPDATE domains
          SET ssl_status = ?, ssl_checked_at = NOW(),
              ssl_issued_at = CASE WHEN ? = 'active' THEN COALESCE(ssl_issued_at, NOW()) ELSE ssl_issued_at END,
              ssl_expires_at = COALESCE(?, ssl_expires_at),
              ssl_self_signed = ?
        WHERE id = ?`,
      [
        status, status,
        cert?.expires_at ? new Date(cert.expires_at).toISOString().slice(0, 19).replace('T', ' ') : null,
        cert?.self_signed ? 1 : 0,
        domainRow.id,
      ],
    );
    return {
      status,
      error: status === 'failed' ? stored.error : '',
      issued_at: stored.issued_at,
      expires_at: cert?.expires_at || domainRow.ssl_expires_at || null,
      days_left: cert?.days_left ?? null,
      live: true,
    };
  } catch {
    return stored;
  }
}

/**
 * Undo pointAtNode: take the domain off the hosting node entirely.
 *
 * THE MISSING HALF. `pointAtNode` creates a DNS zone, a website and a mail
 * domain, and until this existed nothing ever removed them. Both removal paths
 * — the customer's "remove from account" button and the sweep that drops a
 * domain which never verified — only set `status = 'removed'` in our database.
 * The node kept the zone, the vhost and the mail domain forever.
 *
 * That is not merely untidy. The zone keeps answering, so the domain still
 * resolves to us after the customer believes they have taken it away; the mail
 * domain keeps accepting mail for a name we no longer list; the vhost keeps
 * consuming the account's web-domain allowance, so a customer who removes a
 * site and adds another can be told they are at their plan limit when the panel
 * shows fewer domains than they are paying for. And the name stays claimed on
 * the node, so re-adding it later — which `addExternal` explicitly allows —
 * hits "already exists".
 *
 * `v-delete-domain` is one call that removes web, DNS and mail together, which
 * is the exact mirror of `v-add-domain`. Not-exist is success here: this runs on
 * domains that were never pointed at us in the first place, and on ones already
 * cleaned up by a previous attempt.
 *
 * MAIL IS DESTROYED WITH IT, mailboxes and their contents included. That is
 * what removing a domain from a hosting account means, and it is why the caller
 * has to have established that the customer meant this domain.
 */
async function unpointFromNode(domainRow, customer, parts = {}) {
  const { web = true, dns = true, mail = true } = parts;
  const username = customer?.hestia_user;
  if (!username || !domainRow?.domain) {
    return { ok: true, skipped: 'no hosting account', removed: [] };
  }
  if (!hestia.isLive()) return { ok: true, skipped: 'node not live', removed: [] };

  const domain = domainRow.domain;

  /*
   * ALL THREE IS STILL ONE CALL. `v-delete-domain` removes the vhost, the zone
   * and the mail domain together, and doing it in one command rather than three
   * is not just tidier — it is the only version that cannot leave a half-
   * deleted domain behind if the second call fails.
   *
   * The narrow path exists because the customer is now asked WHICH parts to
   * remove. Detaching a website while keeping the zone we answer for is an
   * ordinary thing to want: the zone is what makes their delegation resolve at
   * all, and taking it away turns "this domain is off my hosting plan" into
   * "this domain is off the internet".
   */
  if (web && dns && mail) {
    const removed = [];
    const errors = [];
    let absent = false;
    try {
      await hestia.deleteWebDomain({ username, domain });
      removed.push('website', 'DNS zone', 'mail');
    } catch (err) {
      // 3 is E_NOTEXIST — there was nothing on the node to remove, which is the
      // state we were trying to reach.
      if (err.code === 3) absent = true;
      else return { ok: false, error: err.message, removed: [] };
    }
    await dropOwnRecord(domainRow, username, removed, errors);
    return { ok: errors.length === 0, absent, removed, error: errors.join('; ') };
  }

  // Mail first, then web, then DNS. Order matters on the way out: the zone is
  // the last thing to go, so a failure part-way through leaves a domain that
  // still resolves rather than one that has vanished from DNS with its site
  // still on disk.
  const wanted = [
    mail && { label: 'mail', run: () => hestia.deleteMailDomain({ username, domain }) },
    web && { label: 'website', run: () => hestia.deleteWebsite({ username, domain }) },
    dns && { label: 'DNS zone', run: () => hestia.deleteDnsDomain({ username, domain }) },
  ].filter(Boolean);

  const removed = [];
  const errors = [];
  for (const part of wanted) {
    try {
      // eslint-disable-next-line no-await-in-loop -- three calls, and the order is the point
      await part.run();
      removed.push(part.label);
    } catch (err) {
      // Already gone is the state we wanted.
      if (err.code === 3) continue;
      errors.push(`${part.label}: ${err.message}`);
    }
  }

  if (web) await dropOwnRecord(domainRow, username, removed, errors);

  return { ok: errors.length === 0, removed, error: errors.join('; ') };
}

/**
 * A SUBDOMAIN TAKES ITS OWN A RECORD WITH IT. buildSubdomain wrote one into
 * the parent's zone so the name would resolve; left behind, it keeps the name
 * answering with this server for a site that no longer exists, and the next
 * add reports "it was already there" for a record nobody chose.
 *
 * ONLY the record that points at us. A record with any other value is the
 * customer's own — an external service on that label, say — and is not ours
 * to delete just because a subdomain of the same name was here once.
 *
 * Never fatal: the site is gone, which was the point. A failure is said in
 * `errors`, not hidden.
 */
async function dropOwnRecord(domainRow, username, removed, errors) {
  if (!isSubdomain(domainRow)) return;
  const domain = domainRow.domain;
  try {
    const parentName = parentNameOf(domain);
    const label = parentName ? domain.slice(0, -(parentName.length + 1)) : '';
    if (!label || !(await hestia.dnsDomainExists({ username, domain: parentName }))) return;
    const ours = new Set(await nameservers.ourAddresses(POINT_HOSTNAME).catch(() => []));
    const records = await hestia.listDnsRecords({ username, domain: parentName });
    for (const r of records) {
      if (r.name === label && r.type === 'A' && ours.has(String(r.value).trim())) {
        // eslint-disable-next-line no-await-in-loop -- one record, usually
        await hestia.deleteDnsRecord({ username, domain: parentName, id: r.id });
        removed.push(`A record in ${parentName}`);
      }
    }
  } catch (err) {
    errors.push(`A record: ${err.message}`);
  }
}

/**
 * What actually exists on the node for this domain, right now.
 *
 * Asked of Hestia rather than inferred from our own columns, because the
 * removal form is built from the answer and the two can disagree: a domain
 * whose `dns_enabled` is 1 may have no zone yet (it was never built), and one
 * adopted from the node may have all three with nothing in our database saying
 * so. Offering to delete a mail domain that does not exist, or silently leaving
 * one that does, are both worse than one extra call.
 *
 * NEVER THROWS. Every page that shows the removal card calls this, and a node
 * that is slow or unreachable must degrade to "we cannot tell you what is
 * there" rather than a 500 on a page whose main job is something else.
 */
async function nodeState(domainRow, customer) {
  const empty = {
    known: false, web: false, dns: false, mail: false, dnsRecords: 0, mailboxes: 0,
  };
  const username = customer?.hestia_user;
  if (!username || !domainRow?.domain || !hestia.isLive()) return empty;

  const domain = domainRow.domain;
  try {
    const [web, dns, mail] = await Promise.all([
      hestia.webDomainExists({ username, domain }).catch(() => false),
      hestia.dnsDomainExists({ username, domain }).catch(() => false),
      hestia.mailDomainExists({ username, domain }).catch(() => false),
    ]);

    // Counts only where there is something to count — they are what make the
    // checkbox honest ("and its 7 records") rather than an abstraction.
    const [records, mailDomains] = await Promise.all([
      dns ? hestia.listDnsRecords({ username, domain }).catch(() => []) : [],
      mail ? hestia.listMailDomains(username).catch(() => []) : [],
    ]);

    const box = (mailDomains || []).find((m) => m.domain === domain);
    return {
      known: true,
      web,
      dns,
      mail,
      dnsRecords: (records || []).length,
      mailboxes: box ? Number(box.accounts || 0) : 0,
    };
  } catch {
    return empty;
  }
}

/**
 * Build this domain on the node NOW, without waiting to be convinced.
 *
 * The escape hatch for every version of "it should be working and it is not":
 * a domain delegated to us that we never created a zone for, a vhost deleted by
 * hand, a build that failed the first time. It creates whatever is missing —
 * every step tolerates already-existing — and then runs the ordinary
 * verification, so the answer the customer gets afterwards is the real state of
 * the public DNS rather than a claim about what we just did.
 *
 * Safe to press repeatedly. The only irreversible thing in here is the
 * certificate request, and that is still gated on the name genuinely resolving
 * to this node.
 */
async function rebuild(domainRow, customer) {
  const owner = customer
    || await db.one('SELECT * FROM customers WHERE id = ? LIMIT 1', [domainRow.customer_id]);

  if (!owner?.hestia_user) {
    return { ok: false, error: 'There is no hosting account on this profile yet, so there is nothing to build the site on.' };
  }

  const built = await pointAtNode(domainRow, owner, { force: true });

  // Re-read: pointAtNode writes pointed_at and the SSL columns, and the verify
  // below should see them rather than the stale row we were handed.
  const fresh = await db.one('SELECT * FROM domains WHERE id = ? LIMIT 1', [domainRow.id]) || domainRow;
  const verdict = await verify(fresh, { customer: owner });

  return { ok: Boolean(built.pointed), built, verdict };
}

// ---------------------------------------------------------------------------
// DNS records
// ---------------------------------------------------------------------------

/**
 * Check one record before it is sent to the node.
 *
 * Hestia validates too, and refuses with an exit code — "That value is not
 * valid" is all a customer would see, for any mistake, in any field. These
 * checks exist to say which field and why, in words somebody who has been told
 * to "add a TXT record" by their email provider can act on.
 *
 * Deliberately not exhaustive: it rejects what is definitely wrong rather than
 * trying to be the registry's own parser. A record that passes here and is
 * still refused by the node is reported with the node's own message.
 */
function validateRecord({ name, type, value, priority, ttl }) {
  const out = {
    // `@` is the zone apex and is what Hestia expects for the domain itself.
    name: String(name || '@').trim().toLowerCase().slice(0, 120) || '@',
    type: String(type || '').trim().toUpperCase(),
    value: String(value || '').trim().slice(0, 500),
    priority: '',
    ttl: Math.max(60, Math.min(604800, Number(ttl) || 3600)),
  };

  if (!hestia.DNS_TYPES.includes(out.type)) return { error: 'Pick a record type from the list.' };
  if (!out.value) return { error: 'Give the record a value.' };
  // `@` and `*` are both legal names, not punctuation to be scrubbed: `@` is
  // the zone apex — the domain itself, and the default for most records — and
  // `*` is a wildcard. An earlier version of this pattern left `@` out and
  // rejected every record anybody would add first.
  if (!/^[a-z0-9._*@-]+$/.test(out.name)) {
    return { error: 'A record name can only contain letters, numbers, dots, hyphens, @ and *.' };
  }

  if (out.type === 'A' && !/^\d{1,3}(\.\d{1,3}){3}$/.test(out.value)) {
    return { error: 'An A record points at an IPv4 address, like 203.0.113.10.' };
  }
  if (out.type === 'AAAA' && !/^[0-9a-f:]+$/i.test(out.value)) {
    return { error: 'An AAAA record points at an IPv6 address.' };
  }
  if (['CNAME', 'NS'].includes(out.type) && !/^[a-z0-9.-]+$/i.test(out.value)) {
    return { error: `A ${out.type} record points at a hostname, like example.com.` };
  }

  if (['MX', 'SRV'].includes(out.type)) {
    const p = Number(priority);
    if (!Number.isFinite(p) || p < 0 || p > 65535) {
      return { error: `A ${out.type} record needs a priority between 0 and 65535 — 10 is the usual answer.` };
    }
    out.priority = String(Math.round(p));
  }

  /*
   * A TXT value is quoted for Hestia. SPF and DKIM records contain spaces, and
   * an unquoted value with a space in it becomes several arguments by the time
   * the node's shell sees it — which is how a working SPF record arrives
   * truncated at the first space.
   */
  if (out.type === 'TXT' && !/^".*"$/.test(out.value)) {
    out.value = `"${out.value.replace(/"/g, '')}"`;
  }

  return { ok: true, record: out };
}

/** A name under a domain already on the account. Not a registration. */
function isSubdomain(domainRow) {
  return domainRow?.source === 'subdomain';
}

/**
 * May this customer edit this domain's DNS with us?
 *
 * Only if we are the ones answering for it. A domain delegated to somebody
 * else's nameservers has its zone over there, and an editor that cheerfully
 * accepted records into a zone nobody queries would be a form that does
 * nothing — worse than no form at all, because the customer would believe the
 * change had been made.
 *
 * A SUBDOMAIN NEVER GETS ONE, and not merely because it rarely needs it. A
 * subdomain lives inside its parent's zone; that is the whole reason it does
 * not need a zone of its own. Giving it a second zone here would shadow the
 * records the customer can already edit on the parent — two places to change
 * one name, disagreeing with each other, with no indication of which is
 * winning. The parent's DNS page is the one true place.
 */
function mayEditDns(domainRow, customer) {
  if (!domainRow) return { ok: false, reason: 'Unknown domain.' };

  if (isSubdomain(domainRow)) {
    const parent = parentNameOf(domainRow.domain);
    return {
      ok: false,
      subdomain: true,
      reason: `DNS for a subdomain lives in ${parent ? `${parent}'s` : "its parent domain's"} zone. `
        + 'Edit it there and this name follows.',
    };
  }
  if (!mayPoint(domainRow)) {
    return { ok: false, reason: 'This domain is not pointing at us yet, so its DNS is not ours to edit.' };
  }
  /*
   * Verified by an A record, not by delegation. The site is served here and the
   * certificate is real, but the zone is still at their provider — so this
   * form would write into a zone nobody queries.
   */
  if (domainRow.verify_method === 'a') {
    return {
      ok: false,
      elsewhere: true,
      reason: 'This domain points here with an A record while its DNS stays at your own provider, '
        + 'so its records are changed there. Switch its nameservers to ours and the editor turns on.',
    };
  }
  if (!customer?.hestia_user) {
    return { ok: false, reason: 'DNS hosting comes with a hosting or email plan. There is not one on this account yet.' };
  }
  return { ok: true };
}

/**
 * May this domain have mailboxes, and does the customer have to do anything?
 *
 * SUBDOMAINS ARE REFUSED OUTRIGHT. A mail domain silently starts accepting mail
 * for a name and puts MX expectations on it; nobody should get that on a name
 * they added to host a shop on. Mail belongs on the main domain, and
 * `you@shop.example.com` is not an address anybody wants.
 *
 * `needsRecords` is the difference between the two ways of pointing at us. With
 * our nameservers we write the MX ourselves and mail simply works. With an A
 * record, the zone is theirs and mail cannot arrive until they add the records
 * — so the panel offers the mailbox AND shows exactly what to paste, rather
 * than refusing something that is perfectly possible.
 */
function mayHaveMail(domainRow) {
  if (!domainRow) return { ok: false, reason: 'Unknown domain.' };

  if (isSubdomain(domainRow)) {
    const parent = parentNameOf(domainRow.domain);
    return {
      ok: false,
      subdomain: true,
      reason: `Email is set up on ${parent || 'your main domain'}, not on a subdomain. `
        + 'Addresses look better that way, and a subdomain accepting mail is almost never what anyone wants.',
    };
  }
  if (!mayPoint(domainRow) && !domainRow.mx_verified_at) {
    return {
      ok: false,
      reason: 'This domain is not pointing at us yet, so we cannot accept mail for it. '
        + `For email only, point its MX record at ${MAIL_HOSTNAME} — the website can stay where it is.`,
    };
  }
  /*
   * `needsRecords`: the customer runs their own DNS, so the MX, SPF and DKIM
   * records have to be pasted there — true of a domain verified by A record
   * and of an email-only one alike. Only a domain on our nameservers has them
   * written for it.
   */
  return { ok: true, needsRecords: domainRow.verify_method !== 'ns', mailOnly: !mayPoint(domainRow) };
}

/**
 * The registrable name a subdomain sits under, worked out from the label count
 * rather than looked up — this is for a sentence in the panel, not a decision.
 * The authoritative parent is the row found by addSubdomain().
 */
function parentNameOf(name) {
  const labels = String(name || '').split('.');
  return labels.length > 2 ? labels.slice(1).join('.') : '';
}

// ---------------------------------------------------------------------------
// Dropping
// ---------------------------------------------------------------------------

/**
 * Remove an external domain that never pointed at us.
 *
 * `removed` rather than a DELETE. The customer is told what happened and why,
 * the activity log keeps the answer to "where did my domain go", and adding the
 * same name again later is allowed — `addExternal` claims a removed row back.
 */
async function dropUnverified(domainRow) {
  const [res] = await db.pool.query(
    `UPDATE domains SET status = 'removed', service_id = NULL
      WHERE id = ? AND status = 'awaiting_ns' AND source = 'external'`,
    [domainRow.id],
  );
  if (!res.affectedRows) return { ok: false, already: true };

  const customer = await db.one('SELECT * FROM customers WHERE id = ? LIMIT 1', [domainRow.customer_id]);

  /*
   * Usually a no-op — a domain that never verified was never pointed at the
   * node, so there is nothing to remove. It matters for the one that verified,
   * was built, and then had its nameservers moved away again: without this the
   * zone and mail domain outlive the account they belonged to.
   */
  const unpointed = await unpointFromNode(domainRow, customer);

  await db.logActivity({
    actorType: 'system', action: 'domain.removed_unverified', target: domainRow.domain,
    detail: `Nameservers were never changed. Last seen: ${domainRow.ns_observed || 'nothing'}`
      + (unpointed.ok ? '' : ` Node cleanup failed: ${unpointed.error}`),
    ok: false,
  });

  if (customer) {
    await sendMail({
      to: customer.email,
      subject: `${domainRow.domain} has been removed from your account`,
      html: shell({
        title: `${escapeHtml(domainRow.domain)} was not pointed at us`,
        intro:
          `You added <b>${escapeHtml(domainRow.domain)}</b> to your Vesopa Cloud account, but its `
          + `nameservers were never changed to ours, so we were never able to host it. `
          + `It has been removed from your account — nothing has been charged, and your domain itself is untouched.`,
        bodyHtml: detailTable([
          ['Our nameservers', `<span style="font-family:monospace">${NAMESERVERS.map(escapeHtml).join('<br>')}</span>`],
          ['Last seen pointing at', escapeHtml(domainRow.ns_observed || 'nothing we could read')],
        ]),
        ctaText: 'Add it again',
        ctaUrl: `${SITE_URL}/panel/domains/add`,
        footNote:
          'Change the nameservers at whoever your domain is registered with, then add it here again — '
          + 'it will verify within minutes and we will set the site up for you.',
      }),
    }).catch((err) => console.error('[domains] removal email failed:', err.message));
  }

  return { ok: true };
}

module.exports = {
  buildSubdomain,
  isSubdomain,
  findParent,
  issueSsl,
  sslState,
  SSL_RENEW_WINDOW_DAYS,
  refreshSsl,
  recordSsl,
  explainSslError,
  mayHaveMail,
  parentNameOf,
  graceDeadline,
  mayPoint,
  mayEditDns,
  validateRecord,
  addExternal,
  addSubdomain,
  verify,
  pointAtNode,
  unpointFromNode,
  nodeState,
  rebuild,
  dropUnverified,
};
