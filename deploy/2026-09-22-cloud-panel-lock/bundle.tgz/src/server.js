require('dotenv').config();

const path = require('path');
const http = require('node:http');
const crypto = require('node:crypto');
const express = require('express');
const compression = require('compression');
const cookieParser = require('cookie-parser');

const config = require('./config');
// Vesopa AI and Vesopa Studio: a key must be configured AND AI_FEATURES not
// switched off. Decided once, so the routes and every link agree.
const STUDIO_MOUNTED = require('./ai/bedrock').ENABLED && config.AI.FEATURES_ON;
const db = require('./db');
const { verifyMail } = require('./mailer');
const auth = require('./auth');
const { icon } = require('./icons');
const { asset } = require('./assets');
const currencyContext = require('./currency-context');
const i18n = require('./i18n');
const geo = require('./geo');
const registrar = require('./integrations/domainnameapi');
const hestia = require('./integrations/hestia');

const PORT = Number(process.env.PORT) || 5075;
const HOST = process.env.HOST || '127.0.0.1';
/**
 * The site's own WebSocket origin, for the Content-Security-Policy below.
 *
 * Derived from SITE_URL rather than written down, so a deploy to a different
 * hostname cannot leave the terminal working everywhere except Safari with
 * nothing in any log to say why.
 */
const WSS_ORIGIN = (() => {
  try {
    const url = new URL(config.SITE_URL);
    return `${url.protocol === 'http:' ? 'ws' : 'wss'}://${url.host}`;
  } catch {
    // Should not happen — config.js validates SITE_URL — but a bare `wss:` is
    // the safe wrong answer: the feature works and the policy is one notch
    // broader, rather than the feature silently dying on Safari.
    console.warn('[csp] could not derive a websocket origin from SITE_URL; allowing wss:');
    return 'wss:';
  }
})();

const app = express();

// Behind nginx on the live server, so req.ip is the visitor and not the proxy.
// The login rate limiter counts by IP and is worthless without this.
app.set('trust proxy', 1);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

app.use(compression());
app.use(express.urlencoded({ extended: false, limit: '512kb' }));
/*
 * The raw bytes are kept alongside the parsed body, for one caller.
 *
 * BTCPay signs its webhook with an HMAC over the exact bytes it sent, and
 * `JSON.stringify(req.body)` is not those bytes — it is a re-serialisation
 * that agrees with the original only by luck of key order and number
 * formatting. So the buffer is stashed as it goes past. It costs one reference
 * per JSON request and it is the only way the signature check can be honest.
 */
app.use(express.json({
  // 512 KB is plenty for every JSON body but one: a spoken turn to Vesopa AI
  // carries a WAV clip (16 kHz mono, ~32 KB a second) as base64, and a
  // fifteen-second sentence is 650 KB. /ai/turn is the only route that gets
  // near it, and it checks the clip's own size again (config.AI).
  limit: '2mb',
  verify: (req, _res, buf) => { req.rawBody = buf; },
}));
app.use(cookieParser());

// ---------------------------------------------------------------------------
// Security headers
// ---------------------------------------------------------------------------
// A real CSP is possible here in a way it was not on the EPOS site: this app
// loads nothing from a third-party origin. No CDN, no font host, no analytics.
// 'unsafe-inline' remains for styles only, because the templates set a handful
// of inline `style` attributes for one-off spacing.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  /*
   * ONE inline script per page, and this is what lets it run.
   *
   * The loading bar has to be on screen before first paint, and the only
   * place that runs before first paint is a script in the <head> — see
   * partials/head.ejs. A nonce admits that one script and nothing else:
   * `'unsafe-inline'` would admit an injected one too, and this origin holds
   * a customer's hosting, mail and terminal.
   */
  res.locals.nonce = crypto.randomBytes(16).toString('base64');
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      `script-src 'self' 'nonce-${res.locals.nonce}'`,
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data:",
      "font-src 'self'",
      /*
       * `'self'` AND the site's own wss:// origin, and the second one is not
       * redundant.
       *
       * The spec says `'self'` covers a same-origin WebSocket. WebKit disagrees
       * — Safari has long refused `wss://` under a bare `connect-src 'self'`,
       * and it refuses it silently: the socket never opens, the console shows a
       * CSP violation the customer never sees, and the page just sits there.
       * The panel's terminal and its live status channel are both websockets,
       * so on an iPad the terminal opened, drew its cursor, and did nothing
       * for ever, while working perfectly from a desktop and perfectly against
       * the server when driven directly.
       *
       * Naming the origin costs nothing — it is the same origin the page came
       * from — and it is the difference between the feature existing on an iPad
       * and not.
       */
      `connect-src 'self' ${WSS_ORIGIN}`,
      /*
       * Checkout POSTs to /checkout (self) and the server 303s the browser on
       * to whichever gateway was chosen. Chromium and WebKit apply form-action
       * to that REDIRECT TARGET too, not just the form's own action attribute
       * — so without a gateway's origin here, the browser silently blocks the
       * hand-off and the customer is left stuck on the checkout page with an
       * order that was, in fact, created. No error is shown; it simply does
       * nothing, which is the worst way for a payment to fail.
       *
       * EVERY GATEWAY NEEDS ITS ORIGIN LISTED HERE. Adding an adapter without
       * adding it to this line reproduces that bug exactly.
       *   BosheBoshe   merchant of record, routes to SSLCommerz's own pages
       *   Stripe       checkout.stripe.com hosts the Checkout Session
       *   PayPal       www.paypal.com live, www.sandbox.paypal.com sandbox
       */
      "form-action 'self' https://bosheboshe.com https://*.bosheboshe.com "
        + 'https://sslcommerz.com https://*.sslcommerz.com '
        + 'https://checkout.stripe.com https://*.stripe.com '
        + 'https://www.paypal.com https://www.sandbox.paypal.com https://*.paypal.com',
      "frame-ancestors 'self'",
      "base-uri 'self'",
      "object-src 'none'",
    ].join('; '),
  );
  if (req.secure) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});

// ---------------------------------------------------------------------------
// Static
// ---------------------------------------------------------------------------
app.use(
  express.static(path.join(__dirname, '..', 'public'), {
    maxAge: process.env.NODE_ENV === 'production' ? '7d' : 0,
    etag: true,
  }),
);

// ---------------------------------------------------------------------------
// Language
// ---------------------------------------------------------------------------
// Before everything that reads req.path: it takes /bn off the front, so every
// route below is written once and answers in both languages. See src/i18n.
app.use(i18n.resolve);

// ---------------------------------------------------------------------------
// Locals every view can rely on
// ---------------------------------------------------------------------------
app.use(async (req, res, next) => {
  /*
   * A redirect, when the no-reload router is asking, is a 204 and a header.
   *
   * nav.js fetches links and posts forms itself so the browser never shows its
   * own loading state. `fetch` follows a 303 silently, which leaves the router
   * holding the destination's HTML with no idea what address it belongs to —
   * so a route that redirects tells the router WHERE instead, and the router
   * navigates there itself. Only the shape of the answer changes: every check
   * and every write has already happened by the time a route calls redirect.
   * A request without the header — every ordinary browser navigation, every
   * gateway callback — gets the redirect it always got.
   */
  if (req.get('x-vesopa-nav') === '1') {
    const sendRedirect = res.redirect.bind(res);
    res.redirect = function navRedirect(statusOrUrl, maybeUrl) {
      const url = typeof statusOrUrl === 'string' ? statusOrUrl : maybeUrl;
      if (typeof url !== 'string') return sendRedirect(statusOrUrl, maybeUrl);
      res.setHeader('X-Vesopa-Location', url);
      return res.status(204).end();
    };
  }

  res.locals.siteUrl = config.SITE_URL;
  res.locals.mainSiteUrl = config.MAIN_SITE_URL;
  // Whether the Vesopa account is the only way in — the sign-in page, the
  // header and checkout all draw differently. See config.VESOPA_ONLY.
  res.locals.vesopaOnly = config.VESOPA_ONLY;
  res.locals.contact = config.CONTACT;
  res.locals.brand = config.BRAND;
  res.locals.currentPath = req.path;
  // Path AND query. The currency switcher sends people back to exactly where
  // they were, and on /domains?q=something the query string is the whole page.
  res.locals.currentUrl = req.originalUrl || req.path;
  // Views prefill from the query string (?subject=…), so expose it once here
  // rather than passing it through from every route.
  res.locals.query = req.query || {};
  res.locals.icon = icon;

  /*
   * Dates, said the way a person says them.
   *
   * A DATETIME column arrives as a JS Date, and `<%= row.checked_at %>` prints
   * its toString(): "Sun Aug 30 2026 21:10:02 GMT+0600 (Bangladesh Standard
   * Time)". That is unreadable, it is 60 characters wide in a table cell, and
   * the timezone it names is the SERVER's — which for a UK hosting company
   * running on a box that happens to be set to Asia/Dhaka is actively
   * misleading about when something happened.
   *
   * Recent times are relative, because "4 minutes ago" is what somebody
   * watching a DNS check actually wants to know; older ones get a date.
   */
  res.locals.when = req.i18n.when;

  /*
   * TEXT THAT LIVES IN THE DATABASE, in the language being read.
   *
   * t() translates the furniture, because the English IS the key. It cannot
   * touch a plan's name, its tagline, its badge, its feature list or an
   * offer's headline: those are typed by an admin, they change without a
   * deploy, and they are not keys. So `npm run i18n:check` reported the Bangla
   * complete while the Bangla home page said "Starter", "One website, done
   * properly." and seven English feature lines in the middle of a Bangla page.
   *
   * Each such column has a `_bn` twin. This picks it when the page is Bangla
   * and there is something in it, and falls back to the English otherwise --
   * falling back to the English rather than to nothing, because a plan named
   * in the wrong language still sells and an unnamed one does not.
   */
  res.locals.dbT = (row, field) => {
    if (!row) return '';
    if (req.locale === 'bn') {
      const alt = row[`${field}_bn`];
      if (alt != null && String(alt).trim()) return alt;
    }
    return row[field] == null ? '' : row[field];
  };

  /*
   * A billing term, said in the language being read.
   *
   * The labels in config.TERMS are English data ("1 year"), not translatable
   * keys, so t(term.label) would be a lookup the extractor cannot see and
   * nobody would ever translate. Built from the number of years instead: that
   * is extractable, it takes the plural correctly, and it works for a term
   * nobody has added yet. Shared from here because three pages print it and
   * two copies of this would drift.
   */
  res.locals.termLabel = (term) => {
    const months = Number(term && term.months) || 0;
    if (months === 1) return res.locals.t('Monthly');
    const years = Math.round(months / 12);
    return res.locals.tn('{n} year', '{n} years', years, { n: res.locals.num(years) });
  };

  /** The same, for a column holding one item per line (a feature list). */
  res.locals.dbList = (row, field) => String(res.locals.dbT(row, field) || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);
  // The page's own address in every language, for <link rel="alternate">.
  res.locals.alternates = i18n.alternates(config.SITE_URL, req.path);
  res.locals.localPath = (p) => i18n.localizePath(p, req.locale);
  // Every form that asks for a country renders from the same list.
  res.locals.countries = require('./countries');
  // Appends a deploy stamp to every asset URL. Without it the 7-day max-age
  // below serves old CSS and JS alongside new HTML — see src/assets.js.
  res.locals.asset = asset;
  // money(), moneyParts(), currency, vatPercent and showVat are set by the
  // currency middleware immediately below — they cannot be constants any more,
  // because what they mean depends on who is asking.
  res.locals.nameservers = config.NAMESERVERS;
  // Whether the Vesopa AI widget is drawn (partials/head.ejs, footer.ejs).
  res.locals.aiEnabled = Boolean(config.AI.API_KEY) && config.AI.FEATURES_ON;
  // Whether Vesopa Studio is linked (header, panel rail, phone sheet): only
  // when its routes are actually mounted below.
  res.locals.studioEnabled = STUDIO_MOUNTED;
  res.locals.customer = null;
  res.locals.admin = null;
  res.locals.flash = null;
  res.locals.flashData = null;
  res.locals.csrf = auth.csrfToken(req, res);
  res.locals.cartCount = 0;

  // A one-shot message survives a redirect in a cookie rather than a session
  // store, so "your password was changed" reaches the page it belongs on.
  const flash = req.cookies?.vh_flash;
  if (flash) {
    try {
      const parsed = JSON.parse(Buffer.from(flash, 'base64url').toString('utf8'));
      res.locals.flash = parsed;
      // Split out so a template cannot render the payload by accident when it
      // prints the message. Nothing but the page that expects it looks here.
      res.locals.flashData = parsed.data || null;
    } catch {
      /* a malformed flash is not worth an error page */
    }
    res.clearCookie('vh_flash', { path: '/' });
  }

  next();
});

// The remembered language on a public page's English address, and the switch.
app.use(i18n.redirectRemembered);
app.get('/lang/:code', i18n.switchTo);

/*
 * The strings the browser's own scripts show, as a script rather than inline:
 * the Content-Security-Policy admits one inline script a page and this is not
 * it, and as a file it is cached like every other asset.
 */
const CLIENT_I18N = Object.fromEntries(
  Object.keys(i18n.LOCALES)
    .filter((code) => code !== i18n.DEFAULT_LOCALE)
    .map((code) => [code, `window.VESOPA_I18N=${JSON.stringify(i18n.clientPayload(code))};\n`]),
);
app.get('/i18n/:file', (req, res, next) => {
  const code = String(req.params.file || '').replace(/\.js$/, '');
  if (!CLIENT_I18N[code] || !req.params.file.endsWith('.js')) return next();
  res.type('application/javascript');
  res.set('Cache-Control', process.env.NODE_ENV === 'production' ? 'public, max-age=604800' : 'no-cache');
  return res.send(CLIENT_I18N[code]);
});

/**
 * Which currency is this request in?
 *
 * Before any route, because a route that renders a price has to already know.
 * The `trust proxy` line at the top of this file is what makes the geo half of
 * it work at all — without it every visitor behind nginx looks like 127.0.0.1
 * and the whole site would serve one currency to everybody.
 */
app.use(currencyContext.attach);
app.get('/currency/:code', currencyContext.switchTo);

/*
 * A visitor in Bangladesh is served the Bangla site rather than offered it.
 *
 * Here and not beside i18n.resolve, because this needs req.country and that is
 * the currency middleware's answer. Their own choice, if they have made one,
 * outranks it -- see i18n.redirectByCountry.
 */
app.use(i18n.redirectByCountry);

/** Attach the signed-in customer, if the cookie is valid and still current. */
app.use(async (req, res, next) => {
  const session = auth.readCustomerSession(req);
  if (!session) return next();
  try {
    const customer = await db.one(
      'SELECT * FROM customers WHERE id = ? AND status <> ? LIMIT 1',
      [session.sub, 'closed'],
    );
    // The password fingerprint in the cookie must still match the stored hash;
    // a password change is what invalidates every other device.
    if (customer && auth.passwordVersion(customer.password_hash) === session.pwv) {
      req.customer = customer;
      res.locals.customer = customer;
    }
  } catch (err) {
    console.error('[session] customer lookup failed:', err.message);
  }
  next();
});

/** Cart lives in a cookie until checkout — no rows for an abandoned basket. */
app.use((req, res, next) => {
  try {
    req.cart = req.cookies?.vh_cart ? JSON.parse(Buffer.from(req.cookies.vh_cart, 'base64url').toString('utf8')) : [];
    if (!Array.isArray(req.cart)) req.cart = [];
  } catch {
    req.cart = [];
  }
  res.locals.cartCount = req.cart.length;
  next();
});

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
/*
 * Signing in with a Vesopa account — Phase 6, migration three.
 *
 * Mounted always, and BEFORE the sign-in page: its middleware is what tells
 * the login view whether to draw the button (res.locals.vesopaSso). Mounted
 * after auth-routes, the view rendered before the local was set and the
 * button never appeared -- which is how cloud.vesopa.com sat without
 * Continue with Vesopa while /auth/vesopa/enabled said true.
 */
app.use('/', require('./routes/vesopa-sso').router);
app.use('/', require('./routes/pages'));
app.use('/', require('./routes/domains'));
app.use('/', require('./routes/legal'));
app.use('/', require('./routes/auth-routes'));
app.use('/api/domains', require('./routes/domains-api'));
app.use('/', require('./routes/cart'));
/*
 * Payments sit OUTSIDE /panel deliberately.
 *
 * /pay/ipn is called by the gateway's server, which has no session cookie and
 * would be bounced straight into a login redirect by the panel guard. The two
 * customer-facing routes under here do their own signed-in check.
 */
app.use('/', require('./routes/pay'));
/*
 * Vesopa AI -- the guide on every page. Only when a key is configured: with
 * no key there is no widget (head.ejs reads res.locals.aiEnabled) and no
 * route, so the panel is exactly what it was without it.
 */
if (STUDIO_MOUNTED) {
  app.use('/ai', require('./routes/ai'));
  // Vesopa Studio: build a website by talking (src/builder, routes/build.js).
  app.use('/build', require('./routes/build'));
}
app.use('/panel', require('./routes/panel'));
app.use('/admin', require('./routes/admin'));

// ---------------------------------------------------------------------------
// 404 and error
// ---------------------------------------------------------------------------
app.use((req, res) => {
  res.status(404);
  if (req.path.startsWith('/api/')) return res.json({ error: req.t('Not found.') });
  res.render('public/error', {
    title: req.t('Page not found'),
    robots: 'noindex',
    code: 404,
    heading: req.t('That page does not exist'),
    message: req.t('The link may be out of date, or the address mistyped.'),
  });
});

app.use((err, req, res, _next) => {
  console.error('[error]', err.stack || err.message);
  res.status(err.status || 500);
  if (req.path.startsWith('/api/')) {
    return res.json({ error: i18n.translate(req.locale, 'Something went wrong. Please try again.') });
  }
  res.render('public/error', {
    title: i18n.translate(req.locale, 'Something went wrong'),
    robots: 'noindex',
    code: 500,
    heading: i18n.translate(req.locale, 'Something went wrong at our end'),
    message: i18n.translate(req.locale, 'The problem has been logged. Please try again, or contact support if it keeps happening.'),
  });
});

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
(async () => {
  // Fail loudly and immediately rather than at the first customer's request.
  try {
    await db.ping();
    console.log(`[db] connected to ${process.env.DB_NAME || 'vesopa_hostingdb'}`);
  } catch (err) {
    console.error('[db] could not connect:', err.message);
    console.error('     Check DB_USER / DB_PASSWORD in .env, and that schema.sql has been applied.');
    process.exit(1);
  }

  verifyMail();

  // Currency catalogue up front, so a seed that has not been run is a startup
  // message rather than a mystery on the pricing page.
  try {
    const { all, base, default: def } = await require('./currency').load({ fresh: true });
    console.log(
      `[currency] base ${base.code}, default ${def.code}, selling in `
      + all.filter((c) => c.active).map((c) => `${c.code}@${c.rate}`).join(' '),
    );
    if (all.length === 1) {
      console.warn('           Only one currency configured — run seed.sql to add USD and CAD.');
    }
  } catch (err) {
    console.error('[currency] catalogue unavailable:', err.message);
  }

  const g = geo.status();
  console.log(
    `[geo]      ${g.enabled ? `${g.endpoint}, server-side only` : 'disabled — everyone gets the default currency'}`,
  );

  const reg = registrar.status();
  const node = hestia.status();
  console.log(`[registrar] DomainNameAPI in ${reg.mode.toUpperCase()} mode${reg.configured ? '' : ' (no credentials set)'}`);
  console.log(`[hestia]    node in ${node.mode.toUpperCase()} mode — ${node.host}`);
  if (!reg.live) console.log('            No domain will actually be registered while DNA_MODE=mock.');
  if (!node.live) console.log('            No account will actually be created while HESTIA_MODE=mock.');

  /*
   * Every gateway announces itself, not just the first one.
   *
   * With three adapters, a single line about SSLCommerz was how Stripe sat in
   * mock mode unnoticed: the banner said "LIVE" and meant a different gateway
   * than the one the customer was about to be sent to. One line each, and the
   * mode is read from the adapter rather than from the environment directly,
   * so what is printed is what the adapter will actually do.
   */
  const payments = require('./payments');
  const ssl = require('./integrations/sslcommerz').status();
  const str = require('./integrations/stripe').status();
  const pp = require('./integrations/paypal').status();
  const btc = require('./integrations/btcpay').status();

  console.log(
    `[payments]  SSLCommerz in ${ssl.mode.toUpperCase()} mode${ssl.configured ? '' : ' (no credentials set)'}`
    + `, settling in ${payments.SETTLE_CURRENCY}`,
  );
  console.log(
    `            Stripe in ${str.mode.toUpperCase()} mode${str.configured ? '' : ' (no credentials set)'}`
    + ', charging the order currency',
  );
  console.log(
    `            PayPal in ${pp.mode.toUpperCase()} mode${pp.configured ? '' : ' (no credentials set)'}`
    + ', charging the order currency',
  );
  console.log(
    `            Crypto via BTCPay in ${btc.mode.toUpperCase()} mode${btc.configured ? '' : ' (no credentials set)'}`
    + ', charging the order currency',
  );
  /*
   * A live crypto gateway with no webhook secret is worth a line of its own.
   * It works — the reconciler picks the payment up on its next pass — so
   * nothing looks broken, and the only symptom is that every crypto order sits
   * "awaiting payment" for up to five minutes after the customer has paid.
   * That is precisely the window in which they open a ticket.
   */
  if (btc.live && !btc.webhook) {
    console.warn('            BTCPAY_WEBHOOK_SECRET is not set — crypto payments will settle on the'
      + ' reconciler\'s poll rather than immediately.');
  }

  const mocked = [
    !ssl.live && 'SSLCZ_MODE=mock',
    str.mode === 'mock' && 'STRIPE_MODE=mock',
    pp.mode === 'mock' && 'PAYPAL_MODE=mock',
    btc.mode === 'mock' && 'BTCPAY_MODE=mock',
  ].filter(Boolean);
  if (mocked.length) {
    console.log(`            No payment will actually be taken while ${mocked.join(', ')}.`);
  }
  if (pp.mode === 'sandbox') {
    console.log('            PayPal is on sandbox.paypal.com — real journey, fake money.');
  }

  /*
   * The background jobs: payment reconciliation, late order activation and the
   * nameserver sweep. Started after everything above has reported, so the
   * banner reads as one block and a job's first line cannot appear in the
   * middle of the boot log.
   */
  require('./jobs').start();
  // Domain setups a previous process was running when it stopped are closed
  // honestly rather than left spinning; the next sweep does the real work.
  require('./domain-setup').sweepStale();

  /*
   * BIND TO LOOPBACK, NOT 0.0.0.0.
   *
   * This app always sits behind nginx, which proxies to 127.0.0.1:PORT. Binding
   * every interface — Node's default — publishes the whole site on the server's
   * public address at :5075 as well, in PLAINTEXT and bypassing the certificate
   * entirely. The admin login form is then reachable over unencrypted HTTP on a
   * port nobody is watching, which is exactly how a password gets read off the
   * wire. It was, until this line existed.
   *
   * HOST is overridable for the rare case of a proxy on another machine; the
   * default is the safe one.
   */
  /*
   * An explicit http.Server rather than app.listen(), because the web terminal
   * needs the `upgrade` event and Express does not expose it — an upgrade
   * request never reaches a route. app.listen() creates this same object and
   * hides it; this only makes it reachable.
   */
  const server = http.createServer(app);
  /*
   * Two websocket servers on one http.Server. Each registers its own `upgrade`
   * listener and returns immediately when the path is not its own, so they
   * coexist without a router in front of them — Node calls every listener.
   */
  /*
   * ONE upgrade router, and it is not optional.
   *
   * Node calls every `upgrade` listener on the server, in order, and none of
   * them knows whether another has already answered. So a module that both
   * listens and 404s what it does not recognise silently breaks every other
   * websocket in the process — which is exactly what happened when the live
   * channel was added alongside the terminal.
   *
   * Each handler answers "was this mine?" and only ever touches a socket it has
   * claimed. Nothing claimed it, nothing answered: that is the 404, once, here.
   */
  const upgradeHandlers = [
    require('./terminal').attach(server),
    require('./panel-live').attach(server),
  ];
  server.on('upgrade', (req, socket, head) => {
    for (const handle of upgradeHandlers) {
      try {
        if (handle(req, socket, head)) return;
      } catch (err) {
        console.error('[upgrade] handler threw:', err.message);
        socket.destroy();
        return;
      }
    }
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    socket.destroy();
  });

  server.listen(PORT, HOST, () => {
    console.log(`\n  Vesopa Cloud running on http://${HOST}:${PORT}`);
    console.log(`  Admin panel:               http://${HOST}:${PORT}/admin\n`);
  });
})();
